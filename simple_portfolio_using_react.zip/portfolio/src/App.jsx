import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Outlet, Link } from "react-router-dom";
import Layout from "./pages/Layout";
import Contact from "./pages/Contact";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Portfolio from "./pages/Portfolio";
import User_layout from './pages/user/user_layout';
import Update_profile from "./pages/user/update_profile";
import Update_password from "./pages/user/update_password";
import Logout from "./pages/user/logout";

//user route start

import Dashboard from "./pages/user/dashboard";
import { useEffect, useState } from "react";

//user route end

function App() {

  const [user, setUser] = useState(0);
  // useEffect(() => {
  //   if (sessionStorage.getItem('uid') == "") {
  //     setUser(0);
  //   } else setUser(1);
    
  // }, []);
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={user ? <User_layout  setUser={setUser} /> : <Layout />}>

            <Route index element={<Home />}></Route>
            <Route path="contact" element={<Contact />}></Route>
            <Route path="about" element={<About />}></Route>
            <Route path="services" element={<Services />}></Route>
            <Route path="register" element={<Register />}></Route>
            <Route path="login" element={<Login />}></Route>
            <Route path="portfolio" element={<Portfolio />}></Route>
            <Route path="user/dashboard" element={<Dashboard />}></Route>
            <Route path="user/update_profile" element={<Update_profile />}></Route>
            <Route path="user/update_password" element={<Update_password />}></Route>

          </Route>
        </Routes>
      </BrowserRouter>

    </>

  )
}

export default App;
