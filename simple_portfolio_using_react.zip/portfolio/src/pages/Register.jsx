import { useState } from 'react';
import axios from 'axios';
import image from './images/bg2.jpg';
function Register()
{
    const [name,setName]=useState("");
    const [email,setEmail]=useState("");
    const [phone,setPhone]=useState("");
    const [password,setPassword]=useState("");
     const imageStyle={
                width:'100%',
                height:'100vh',
                backgroundImage:`url(${image})`,
                backgroundSize:'100% 100%',
                overflow:'hidden'
                
        };
    const numberCheck = (e) => {
      var phone=e.target.value;
      if(/^\d*$/.test(phone))
      {
        setPhone(phone);
      }
    }
    const handleSubmit = (e) => {
        e.preventDefault();

        const data={
          name:name,
          email:email,
          phone:phone,
          password:password,
          cmd:'register'
        };

        if(name.length==0)
        {
           alert('Please enter name');
           return;
        }
        if(phone.length==0)
        {
          alert('Please enter phone no');
          return;
        }
        if(email.length==0)
        {
            alert('Please enter email');
            return;
        }
        if(password.length==0)
        {
            alert('Please enter password');
            return;
        }

        axios.post('http://localhost:8001/php/backend.php',data)
        .then((response)=>{
          alert(response.data.message);
            setName("");
            setEmail("");
            setPhone("");
            setPassword("");
        })
        .catch((error)=>{
          alert(error);
        });
    }
    return(
        <>
        <div style={imageStyle}>
        <div  style={{marginTop:"100px"}}>
        <h1 className="text-center text-white">Register</h1>
        <p className="text-center text-white">Enter your Credentials to Register our site</p>
        <div className="container">
        
        <div>
            <div className="mt-5 mb-5">
                <div className="p-5 shadow bg-white border">
                <form action="" onSubmit={handleSubmit} autoComplete='off'>
<div className="row">
  <div className="mb-3 mt-3 ">
    <label htmlFor="name" className="form-label">Name:</label>
    <input type="text" className="form-control" id="name" placeholder="Enter name" onChange={(e)=>setName(e.target.value)} value={name} name="name" />
  </div>
  <div className="mb-3 mt-3 ">
    <label htmlFor="phone" className="form-label">Phone:</label>
    <input type="text" className="form-control" id="phone" placeholder="Enter phone" value={phone} maxLength="10" onChange={numberCheck} name="phone" />
  </div>
  <div className="mb-3 mt-3 ">
    <label htmlFor="email" className="form-label">Email:</label>
    <input type="text" className="form-control" id="email" placeholder="Enter email" value={email} name="email"  onChange={(e)=>setEmail(e.target.value)} />
  </div>
  </div>
  <div className="mb-3 mt-3">
    <label htmlFor="password" className="form-label">Password:</label>
    <input type="password" className="form-control" id="password" placeholder="Enter password" value={password}  onChange={(e)=>setPassword(e.target.value)} name="password" />
  </div>
  <button type="submit" className="btn btn-primary mt-2">Register</button>
</form>
                </div>
            </div>
        </div>
            
        </div>
        </div>
        </div>
        </>
    );
}
export default Register;