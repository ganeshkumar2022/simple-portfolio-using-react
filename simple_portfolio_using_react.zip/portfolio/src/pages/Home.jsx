import image from './images/bg.jpg';
import image2 from './images/profile-img.jpg';
import facebookicon from './images/facebook.png';
import googleicon from './images/google.png';
import instagramicon from './images/instagram.png';
import youyubeicon from './images/youtube.png';
function Home()
{
    const imageStyle={
        width:'100%',
        height:'100vh',
        backgroundImage:`url(${image})`,
        backgroundSize:'100% 100%',
        overflow:'hidden'
        
    };
    return(
        <>
        <div style={imageStyle}>
            <div style={{backgroundColor:"rgba(0,0,0,0.4)",height:"100%"}}>
            <div className='container'>
            <div className='row'>
                <div className='col-md-6' style={{marginTop:"400px"}}>
                    <h1 className='text-white fw-bold' style={{fontSize:'60px'}}>I am Sanjay</h1>
                    <h3 className='text-white' style={{fontSize:'45px',fontFamily:'cursive'}}>I am a python developer.</h3>
                    <div style={{fontSize:"25px"}}>
                        <a href="" className='text-decoration-none text-white me-3'><img src={facebookicon} className='img-icon' /></a>
                        <a href="" className='text-decoration-none text-white me-3'><img src={googleicon} className='img-icon' /></a>
                        <a href="" className='text-decoration-none text-white me-3'><img src={instagramicon} className='img-icon' /></a>
                        <a href="" className='text-decoration-none text-white me-3'><img src={youyubeicon} className='img-icon' /></a>
                    </div>
                </div>
                <div className='col-md-6' style={{marginTop:"250px"}}>
<img src={image2} style={{height:"400px"}} />
                </div>
            </div>
            </div>
            </div>
        </div>
        </>
    );
}

export default Home;