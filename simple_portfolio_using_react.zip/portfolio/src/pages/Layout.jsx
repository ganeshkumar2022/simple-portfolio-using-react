import 'bootstrap/dist/css/bootstrap.min.css';
import { Outlet,Link } from "react-router-dom";
function Layout({setUser})
{
    return(
        <>
        <nav className="navbar navbar-expand-sm bg-primary fixed-top navbar-dark">
  <div className="container-fluid">
    <a className="navbar-brand" href="#"><img src="/726107.png" style={{height:"30px",width:"30px"}} /> Portfolio</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
      <ul className="navbar-nav">
      <li className="nav-item">
          <Link to="/" className="nav-link">Home</Link>
      </li>
      <li className="nav-item">
          <Link to="/contact" className="nav-link">Contact</Link>
      </li>
      <li className="nav-item">
          <Link to="/about" className="nav-link">About</Link>
      </li>
      <li className="nav-item">
          <Link to="/services" className="nav-link">Services</Link>
      </li>
      </ul>
    </div>
  </div>
</nav>
        <Outlet/>
        </>
    );
}
export default Layout;