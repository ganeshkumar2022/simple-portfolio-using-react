import { useState,useEffect } from 'react';
import Layouts from "./user_layout";
import axios from 'axios';
function update_profile()
{


    const [name,setName]=useState("");
    const [email,setEmail]=useState("");
    const [phone,setPhone]=useState("");


        //get specific user data start
        useEffect(()=>{
            
            const user_id=sessionStorage.getItem('uid');
            axios.get('http://localhost:8001/php/backend.php?cmd=get_single_user&uid='+user_id)
            .then((response)=>{
              var name=response.data.name;
              var phone=response.data.phone;
              var email=response.data.email;
              setName(name);
              setEmail(email);
              setPhone(phone);
            })
            .catch((error)=>{
              alert(error);
            });

        },[]);
        
    
        //get specific user data end

    const numberCheck = (e) => {
        var phone=e.target.value;
        if(/^\d*$/.test(phone))
        {
          setPhone(phone);
        }
      }
      const handleSubmit = (e) => {
          e.preventDefault();
  
          const data={
            name:name,
            email:email,
            phone:phone,
            cmd:'update_profile',
            uid:sessionStorage.getItem('uid')
          };
  
          if(name.length==0)
          {
             alert('Please enter name');
             return;
          }
          if(phone.length==0)
          {
            alert('Please enter phone no');
            return;
          }
          if(email.length==0)
          {
              alert('Please enter email');
              return;
          }
  
          axios.post('http://localhost:8001/php/backend.php',data)
          .then((response)=>{
            alert(response.data.message);
              setName("");
              setEmail("");
              setPhone("");
              window.location.replace(window.location.href);
          })
          .catch((error)=>{
            alert(error);
          });
      }
    return(
        <>
        <Layouts/>
         <div  style={{marginTop:"100px"}}>
        <h1 className="text-center text-dark">Update Profile</h1>
        <p className="text-center text-primary">Enter new Credentials to update your profile</p>
        <div className="container">
        
        <div>
            <div className="mt-5 mb-5">
                <div className="p-5 shadow bg-white border">
                <form action="" onSubmit={handleSubmit} autoComplete='off'>
<div className="row">
  <div className="mb-3 mt-3 ">
    <label htmlFor="name" className="form-label">Name:</label>
    <input type="text" className="form-control" id="name" placeholder="Enter name" onChange={(e)=>setName(e.target.value)} value={name} name="name" />
  </div>
  <div className="mb-3 mt-3 ">
    <label htmlFor="phone" className="form-label">Phone:</label>
    <input type="text" className="form-control" id="phone" placeholder="Enter phone" value={phone} maxLength="10" onChange={numberCheck} name="phone" />
  </div>
  <div className="mb-3 mt-3 ">
    <label htmlFor="email" className="form-label">Email:</label>
    <input type="text" className="form-control" id="email" placeholder="Enter email" value={email} name="email"  onChange={(e)=>setEmail(e.target.value)} />
  </div>
  </div>
  <button type="submit" className="btn btn-primary mt-2">Update</button>
</form>
                </div>
            </div>
        </div>
            
        </div>
        </div>
        </>
    );
}
export default update_profile;