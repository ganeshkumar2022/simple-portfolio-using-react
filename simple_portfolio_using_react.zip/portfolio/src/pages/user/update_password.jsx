
import axios from 'axios';
import { useState } from 'react';
import Layout from "./user_layout";
function update_password()
{
    const [password,setPassword]=useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
  
        const data={
          password:password,
          uid:sessionStorage.getItem('uid'),
          cmd:'update_password'
        };
  

        if(password.length==0)
        {
            alert('Please enter password');
            return;
        }
  
        axios.post('http://localhost:8001/php/backend.php',data)
        .then((response)=>{
          setPassword("");
          if(response.data.status=="success")
          {
            alert(response.data.message);
          }
          else
          {
            alert(response.data.message);
          }
         
        })
        .catch((error)=>{
          alert(error);
        });
    }

    return(
        <>
        <div>
          
        <Layout/>
        <div  style={{marginTop:"100px"}}>
        <h2 className="text-center text-dark">Update Password</h2>
        <p className="text-center text-primary">Enter your New password to update your password</p>
        <div className="container">
        
        <div>
            <div className="mt-5 mb-5">
                <div className="p-5 shadow bg-white border">
                <form action="" onSubmit={handleSubmit} autoComplete='off'>
<div className="row">
  </div>
  <div className="mb-3 mt-3">
    <label htmlFor="password" className="form-label">Password:</label>
    <input type="password" className="form-control" id="password" placeholder="Enter password" value={password}  onChange={(e)=>setPassword(e.target.value)} name="password" />
  </div>
  <button type="submit" className="btn btn-primary mt-2">Update</button>
</form>
                </div>
            </div>
        </div>
            
        </div>
        </div>
        </div>
        </>
    );
}
export default update_password;