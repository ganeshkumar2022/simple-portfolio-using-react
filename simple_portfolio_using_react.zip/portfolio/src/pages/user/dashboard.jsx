import Layout from "./user_layout";
function dashboard()
{
    return(
        <>
        <Layout/>
        <div style={{marginTop:'80px'}}>
        
        </div>
        </>
    );
}
export default dashboard;