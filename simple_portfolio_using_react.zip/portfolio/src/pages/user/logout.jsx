import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
function logout()
{
   const navigate=useNavigate();
   useEffect(()=>{
   sessionStorage.removeItem('uid');
   navigate('/login');
   },[]);
}
export default logout;