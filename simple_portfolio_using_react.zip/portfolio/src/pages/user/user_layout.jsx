import 'bootstrap/dist/css/bootstrap.min.css';
import { useEffect } from 'react';
import { Outlet, Link, useNavigate } from "react-router-dom";
function Layout({setUser}) {
  const navigate = useNavigate();
  function logout(event) {
    event.preventDefault();

    localStorage.removeItem('uid');
    navigate('/login');
  }

  return (
    <>
      <nav className="navbar navbar-expand-sm bg-primary fixed-top navbar-dark">
        <div className="container-fluid">
          <a className="navbar-brand" href="#"><img src="/726107.png" style={{ height: "30px", width: "30px" }} /> User Panel</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to="/user/dashboard" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to="/user/update_profile" className="nav-link">Update profile</Link>
              </li>
              <li className="nav-item">
                <Link to="/user/update_password" className="nav-link">Update Password</Link>
              </li>
              <li className="nav-item">
                <a onClick={(event) => logout(event)} href='#' className="nav-link">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
export default Layout;