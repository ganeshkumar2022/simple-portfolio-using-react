import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import axios from 'axios';
import image from './images/bg2.jpg';
function Login()
{
  
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const navigate=useNavigate();
     const imageStyle={
            width:'100%',
            height:'100vh',
            backgroundImage:`url(${image})`,
            backgroundSize:'100% 100%',
            overflow:'hidden'
            
    };

    const handleSubmit = (e) => {
      e.preventDefault();

      const data={
        email:email,
        password:password,
        cmd:'login'
      };

      if(email.length==0)
      {
          alert('Please enter email');
          return;
      }
      if(password.length==0)
      {
          alert('Please enter password');
          return;
      }

      axios.post('http://localhost:8001/php/backend.php',data)
      .then((response)=>{
        setEmail("");
        setPassword("");
        if(response.data.status=="success")
        {
          alert(response.data.message);
          const uid=response.data.uid;
          localStorage.setItem('uid',uid);
          navigate('/user/dashboard');
        }
        else
        {
          alert(response.data.message);
        }
       
      })
      .catch((error)=>{
        alert(error);
      });
  }

    return(
        <>
        <div style={imageStyle}>
        <div  style={{marginTop:"100px"}}>
        <h1 className="text-center text-white">Login</h1>
        <p className="text-center text-white">Enter your Credentials to login our site</p>
        <div className="container">
        
        <div>
            <div className="mt-5 mb-5">
                <div className="p-5 shadow bg-white border">
                <form action="" onSubmit={handleSubmit} autoComplete='off'>
<div className="row">
<div className="mb-3 mt-3 ">
    <label htmlFor="email" className="form-label">Email:</label>
    <input type="text" className="form-control" id="email" placeholder="Enter email" value={email} name="email"  onChange={(e)=>setEmail(e.target.value)} />
  </div>
  </div>
  <div className="mb-3 mt-3">
    <label htmlFor="password" className="form-label">Password:</label>
    <input type="password" className="form-control" id="password" placeholder="Enter password" value={password}  onChange={(e)=>setPassword(e.target.value)} name="password" />
  </div>
  <button type="submit" className="btn btn-primary mt-2">Login</button>
</form>
                </div>
            </div>
        </div>
            
        </div>
        </div>
        </div>
        </>
    );
}
export default Login;