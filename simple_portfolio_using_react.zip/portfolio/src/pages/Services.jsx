function Services()
{
    return(
        <>
        <div  style={{marginTop:"100px"}}>
        <h1 className="text-center">Services</h1>
        <p className="text-center">Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
        <div className="container">
        <div className="row mt-5">
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-windows p-3 border rounded-circle"></i>
                
                <h3 className="mt-3">Web development</h3>
                
                </center>
                <p style={{textAlign:"justify"}}>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                </p>
            </div>
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-snowflake p-3 border rounded-circle"></i>
                
                <h3 className="mt-3">Responsive Design</h3>
                
                </center>
                <p style={{textAlign:"justify"}}>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                </p>
            </div>
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-s p-3 border rounded-circle"></i>
               
                <h3 className="mt-3">SEO Work</h3>
                
                </center>
                <p style={{textAlign:"justify"}}>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                </p>
            </div>
        </div>
        <div>
            
        </div>
            
        </div>
        </div>
        </>
    );
}
export default Services;