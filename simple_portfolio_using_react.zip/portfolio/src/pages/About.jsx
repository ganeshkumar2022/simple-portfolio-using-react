import image from './images/profile-img.jpg';
function About()
{
    return(
        <>
        <div  style={{marginTop:"100px"}}>
       
        <div className="container">
        <div className="row mt-5">
            <div className="col-md-6">
                <img src={image} style={{height:"400px"}} />
            </div>
            <div className="col-md-6">
            <h3>About Us</h3>
            <h5>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</h5>
            <ol className="">
                <li>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos, temporibus!
                </li>
                <li>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                </li>
                <li>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos, temporibus!
                    lorem10
                </li>
            </ol> 
            </div>
        </div>
        <div>
           
        </div>
            
        </div>
        </div>
        </>
    );
}
export default About;