import { useState } from 'react';
import axios from 'axios';
function Contact()
{
    const [name,setName]=useState("");
    const [email,setEmail]=useState("");
    const [subject,setSubject]=useState("");
    const [message,setMessage]=useState("");

    const handleSubmit = (e) => {
        e.preventDefault();

        const data={
          name:name,
          email:email,
          subject:subject,
          message:message,
          cmd:'enquiry'
        };

        if(name.length==0)
        {
           alert('Please enter name');
           return;
        }
        if(email.length==0)
        {
            alert('Please enter email');
            return;
        }
        if(subject.length==0)
        {
            alert('Please enter subject name');
            return;
        }
        if(message.length==0)
        {
            alert('Please enter message');
            return;
        }

        axios.post('http://localhost:8001/php/backend.php',data)
        .then((response)=>{
          alert(response.data.message);
            setName("");
            setEmail("");
            setSubject("");
            setMessage("");
        })
        .catch((error)=>{
          alert(error);
        });
    }

    return(
        <>
        <div  style={{marginTop:"100px"}}>
        <h1 className="text-center">Contact Us</h1>
        <p className="text-center">Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
        <div className="container">
        <div className="row mt-5 border p-5 shadow">
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-map-location-dot p-3 border rounded-circle"></i>
                
                <h3 className="mt-3">Address</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem, incidunt.
                </p>
                </center>
            </div>
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-phone p-3 border rounded-circle"></i>
                
                <h3 className="mt-3">Call</h3>
                <p>
                    +91 97645 12455
                </p>
                </center>
            </div>
            <div className="col-md-4">
                <center>
                <i className="fa-solid fa-envelope p-3 border rounded-circle"></i>
               
                <h3 className="mt-3">Email</h3>
                <p>
                    sanjaykumar@gmail.com
                </p>
                </center>
            </div>
        </div>
        <div>
            <div className="mt-5 mb-5">
                <div className="p-5 shadow border">
                <form action="" method="post" onSubmit={handleSubmit} autoComplete='off'>
<div className="row">
  <div className="mb-3 mt-3 col">
    <label htmlFor="name" className="form-label">Name:</label>
    <input type="text" className="form-control" id="name" placeholder="Enter name" onChange={(e)=>setName(e.target.value)} value={name} name="name" />
  </div>
  <div className="mb-3 mt-3  col">
    <label htmlFor="email" className="form-label">Email:</label>
    <input type="text" className="form-control" id="email" placeholder="Enter email" name="email" onChange={(e)=>setEmail(e.target.value)} value={email} />
  </div>
  </div>
  <div className="mb-3">
    <label htmlFor="subject" className="form-label">Subject:</label>
    <input type="text" className="form-control" id="subject" placeholder="Enter subject" name="subject" onChange={(e)=>setSubject(e.target.value)} value={subject} />
  </div>
  <div>
  <label htmlFor="message">Message:</label>
  <textarea className="form-control" rows="5" onChange={(e)=>setMessage(e.target.value)} value={message} id="message" name="message"></textarea>
  </div>
  <button type="submit" className="btn btn-primary mt-2">Send Message</button>
</form>
                </div>
            </div>
        </div>
            
        </div>
        </div>
        </>
    );
}

export default Contact;