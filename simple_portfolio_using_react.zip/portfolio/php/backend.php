<?php

header("Access-Control-Allow-Origin: *");  // Replace '*' with a specific URL if needed

// Allow specific methods (e.g., GET, POST, PUT, DELETE)
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

// Allow specific headers
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// Allow credentials if you need to send cookies or authentication
header("Access-Control-Allow-Credentials: true");

// Set the allowed response time for the browser to cache the preflight request
header("Access-Control-Max-Age: 3600");  // 1 hour


header("Content-Type: application/json; charset=UTF-8");

//db connect start
$servername="localhost";
$username="root";
$passwor="";
$database="react_portfolio";
$str="mysql:host=$servername;dbname=$database";
try
{
    $con=new PDO($str,$username,$passwor);
}
catch(PDOException $e)
{
    $data=["message"=>"Error to connect database"];
    echo json_encode($data);
    exit;
}
//db connect end

if($_SERVER['REQUEST_METHOD']=="GET")
{
    $cmd=$_GET['cmd'];
    if($cmd=="get_single_user")
    {
        $uid=$_GET['uid'];
        $sql2="select * from user where id=:uid";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":uid",$uid);
        $result2->execute();
        $row2=$result2->fetch();
        echo json_encode($row2);
        exit;
    }
}


if($_SERVER['REQUEST_METHOD']=="POST")
{
    $input_data=json_decode(file_get_contents("php://input"),true);
    $cmd=$input_data['cmd'];

    if($cmd=="register")
    {
        $name=$input_data['name'];
        $email=$input_data['email'];
        $phone=$input_data['phone'];
        $password=$input_data['password'];

        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $data=["message"=>"Email Address not valid"];
            echo json_encode($data);
            exit;
        }

        //email validation start
        $sql2="select * from user where email=:email";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":email",$email);
        $result2->execute();
        $row2=$result2->fetch();
        if($row2)
        {
            $data=["message"=>"Email already exists"];
            echo json_encode($data);
            exit;
        }
        //email validation end

        //phone validation start
        $sql2="select * from user where phone=:phone";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":phone",$phone);
        $result2->execute();
        $row3=$result2->fetch();
        if($row3)
        {
            $data=["message"=>"Mobile no already exists"];
            echo json_encode($data);
            exit;
        }
        //phone validation end



        $sql="insert into user (name,email,phone,password) values (:name,:email,:phone,:password)";
        $result=$con->prepare($sql);
        $result->bindParam(":name",$name);
        $result->bindParam(":email",$email);
        $result->bindParam(":phone",$phone);
        $result->bindParam(":password",$password);

        try
        {
            $result->execute();
            $data=["message"=>"Registered successfully"];
            echo json_encode($data);
        }
        catch(Exception $e)
        {
            $data=["message"=>"Error to Register"];
            echo json_encode($data);
        }

     
    }
    if($cmd=="login")
    {
        $email=$input_data['email'];
        $password=$input_data['password'];

        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $data=["message"=>"Email Address not valid"];
            echo json_encode($data);
            exit;
        }

        $sql2="select * from user where email=:email and password=:password";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":email",$email);
        $result2->bindParam(":password",$password);
        $result2->execute();
        $row2=$result2->fetch();
        if($row2)
        {
            $data=["message"=>"Login Successfully","uid"=>$row2['id'],"status"=>"success"];
            echo json_encode($data);
            exit;
        }
        else
        {
            $data=["message"=>"Email or password incorrect","status"=>"failure"];
            echo json_encode($data);
            exit; 
        }
    }
    if($cmd=="update_password")
    {
        $uid=$input_data['uid'];
        $password=$input_data['password'];


        $sql2="update user set password=:password where id=:uid";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":uid",$uid);
        $result2->bindParam(":password",$password);
        
        try
        {
            $result2->execute();
            $data=["message"=>"Password Updated Successfully","status"=>"success"];
            echo json_encode($data);
            exit;
        }
        catch(Exception $e)
        {
            $data=["message"=>"Error to Update Password","status"=>"failure"];
            echo json_encode($data);
            exit; 
        }
    }

    if($cmd=="enquiry")
    {
        $name=$input_data['name'];
        $email=$input_data['email'];
        $subject=$input_data['subject'];
        $message=$input_data['message'];

        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $data=["message"=>"Email Address not valid"];
            echo json_encode($data);
            exit;
        }

        //email validation start
        $sql2="select * from user where email=:email";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":email",$email);
        $result2->execute();
        $row2=$result2->fetch();
        if($row2)
        {
            $data=["message"=>"Email already exists"];
            echo json_encode($data);
            exit;
        }
        //email validation end




        $sql="insert into enquiry (name,email,subject,message) values (:name,:email,:subject,:message)";
        $result=$con->prepare($sql);
        $result->bindParam(":name",$name);
        $result->bindParam(":email",$email);
        $result->bindParam(":subject",$subject);
        $result->bindParam(":message",$message);

        try
        {
            $result->execute();
            $data=["message"=>"Enquiry Form submitted successfully"];
            echo json_encode($data);
        }
        catch(Exception $e)
        {
            $data=["message"=>"Error to Submit Enquiry Form"];
            echo json_encode($data);
        }

     
    }

    if($cmd=="update_profile")
    {
        $name=$input_data['name'];
        $email=$input_data['email'];
        $phone=$input_data['phone'];
        $uid=$input_data['uid'];

        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $data=["message"=>"Email Address not valid"];
            echo json_encode($data);
            exit;
        }

        //email validation start
        $sql2="select * from user where email=:email and id!=:id";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":email",$email);
        $result2->bindParam(":id",$uid);
        $result2->execute();
        $row2=$result2->fetch();
        if($row2)
        {
            $data=["message"=>"Email already exists"];
            echo json_encode($data);
            exit;
        }
        //email validation end

        //phone validation start
        $sql2="select * from user where phone=:phone and id!=:id";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":phone",$phone);
        $result2->bindParam(":id",$uid);
        $result2->execute();
        $row3=$result2->fetch();
        if($row3)
        {
            $data=["message"=>"Mobile no already exists"];
            echo json_encode($data);
            exit;
        }
        //phone validation end



        $sql="update user set name=:name,email=:email,phone=:phone where id=:uid";
        $result=$con->prepare($sql);
        $result->bindParam(":name",$name);
        $result->bindParam(":email",$email);
        $result->bindParam(":phone",$phone);
        $result->bindParam(":uid",$uid);

        try
        {
            $result->execute();
            $data=["message"=>"Profile Updated successfully"];
            echo json_encode($data);
        }
        catch(Exception $e)
        {
            $data=["message"=>$e->getMessage()];
            echo json_encode($data);
        }

     
    }

}
?>